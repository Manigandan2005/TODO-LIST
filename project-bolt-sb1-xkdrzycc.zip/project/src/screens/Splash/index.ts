export { Splash } from "./Splash";
